//
//  NavigationBarModifier.swift
//  sketch-elements
//
//  Created by Filip Molcik on 14/03/2020.
//  Copyright © 2020 Filip Molcik. All rights reserved.
//

import SwiftUI

struct NavigationBarModifier: ViewModifier {
    
    var backgroundColor: UIColor?
    var blabla  = UINavigationItem.BackButtonDisplayMode.minimal
    init( backgroundColor: UIColor?) {
        self.backgroundColor = backgroundColor
        let coloredAppearance = UINavigationBarAppearance()
        coloredAppearance.configureWithTransparentBackground()
        coloredAppearance.backgroundColor = .clear
        
        //Les  couleurs des titres  'normal'
        coloredAppearance.titleTextAttributes = [.foregroundColor: UIColor(Color("Color_Other"))]
        coloredAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor(Color("Color_Other"))]
        UINavigationBar.appearance().standardAppearance = coloredAppearance
        UINavigationBar.appearance().compactAppearance = coloredAppearance
        UINavigationBar.appearance().scrollEdgeAppearance = coloredAppearance
        
        //Les  couleurs des titres  'back'
        UINavigationBar.appearance().tintColor = UIColor(Color("Color_Other"))
    }
    
    func body(content: Content) -> some View {
        ZStack{
            content
            VStack {
                GeometryReader { geometry in
                    Color(self.backgroundColor ?? .clear)
                        .frame(height: geometry.safeAreaInsets.top)
                        .edgesIgnoringSafeArea(.top)
                    Spacer()
                }
            }
        }
    }
}
