//  EcoMojo
//
//  Created by Groupe environement
//
//Tuto by https://vu.fr/PT49
import SwiftUI
//enum des directions en jeux
enum direction {
    case up, down, left, right
}
struct snaketView: View {
    //Déclaration des variables utiles.
    @State var startPos : CGPoint = .zero //Position du camion poubelle
    @State var isStarted = true     //Booleen état du jeux
    @State var gameOver = false     //Booleen perde ?
    
    //Déclaration du Timer pour la boucle
    let timer = Timer.publish(every: 0.15, on: .main, in: .common).autoconnect()
    //Déclaration Binding variable
    @State var dir = direction.down
    @State var posArray = [CGPoint(x: 0, y: 0)]     //Position du camion
    @State var foodPos = CGPoint(x: 0, y: 0)        //Position poubelle
    @State var countTrash = 0                     //Compteur score
    
    let snakeSize : CGFloat = 40
    //Taille du Snake
    
    var body: some View {
        ZStack {
            Color("Color_BackGround").opacity(0.9) //Mise en place de la couleur de fond
            ZStack {
                ForEach (0..<posArray.count, id: \.self) { index in
                    Image("GarbageTruck")   //Image du camion poubelle & paramètre
                        .resizable()
                        .scaledToFit()
                        .frame(width: self.snakeSize, height: self.snakeSize)
                        .position(self.posArray[index])
                }
                Image("Dust")       //Image de  la poubelle & paramètre
                    .resizable()
                    .frame(width: snakeSize * 0.4, height: snakeSize * 0.4)
                    .shadow(color: Color("Color_Shadow"), radius: 10, x: 0, y: 0)
                    .position(foodPos)
                
            }
            
            if self.gameOver {
                Text("")    //astuce pour créer l'alerte de game over
                    .alert(isPresented: $gameOver) {
                        Alert(title: Text("Game Over"), message: Text("Score:  \(countTrash)"), primaryButton: Alert.Button.default(Text("Recommencer"), action: {
                            gameOver = false
                            posArray = [CGPoint(x: 0, y: 0)]
                            foodPos  = self.changeRectPos()
                            posArray[0] = self.changeRectPos()
                        }
                        
                        ), secondaryButton: Alert.Button.default(Text("Stop"), action: {
                            posArray = [CGPoint(x: 0, y: 0)]
                            foodPos  = self.changeRectPos()
                            posArray[0] = self.changeRectPos()
                            gameOver = true
                        } ) ) } }
        }.onAppear() { //Création des positions aléatoire
            self.foodPos = self.changeRectPos()
            self.posArray[0] = self.changeRectPos()
        }
        .gesture(DragGesture() //Geste = Commande
                    .onChanged { gesture in
                        if self.isStarted {
                            self.startPos = gesture.location
                            self.isStarted.toggle()
                        }
                    }
                    .onEnded {  gesture in
                        let xDist =  abs(gesture.location.x - self.startPos.x)
                        let yDist =  abs(gesture.location.y - self.startPos.y)
                        if self.startPos.y <  gesture.location.y && yDist > xDist {
                            self.dir = direction.down
                        }
                        else if self.startPos.y >  gesture.location.y && yDist > xDist {
                            self.dir = direction.up
                        }
                        else if self.startPos.x > gesture.location.x && yDist < xDist {
                            self.dir = direction.right
                        }
                        else if self.startPos.x < gesture.location.x && yDist < xDist {
                            self.dir = direction.left
                        }
                        self.isStarted.toggle()
                    }
        )
        .onReceive(timer) { (_) in //trasmission de la poubelle absorbé.
            if !self.gameOver {
                self.changeDirection()
                if self.posArray[0] == self.foodPos {
                    self.posArray.append(self.posArray[0])
                    self.foodPos = self.changeRectPos()
                    self.countTrash = posArray.count - 1 //compteur du score
                }
            }
        }
        .edgesIgnoringSafeArea(.all)
    }
    
    let minX = UIScreen.main.bounds.minX
    let maxX = UIScreen.main.bounds.maxX
    let minY = UIScreen.main.bounds.minY
    let maxY = UIScreen.main.bounds.maxY
    
    //fonction d'appel au changement de direction
    func changeDirection () {

        if self.posArray[0].x < minX || self.posArray[0].x > maxX && !gameOver{
            gameOver.toggle()
        }
        else if self.posArray[0].y < minY || self.posArray[0].y > maxY  && !gameOver {
            gameOver.toggle()
        }
        var prev = posArray[0]
        if dir == .down {
            self.posArray[0].y += snakeSize
        } else if dir == .up {
            self.posArray[0].y -= snakeSize
        } else if dir == .left {
            self.posArray[0].x += snakeSize
        } else {
            self.posArray[0].x -= snakeSize
        }
        
        for index in 1..<posArray.count {
            let current = posArray[index]
            posArray[index] = prev
            prev = current
        }
    }
    
    func changeRectPos() -> CGPoint {
        let rows = Int(maxX/snakeSize)
        let cols = Int(maxY/snakeSize)
        
        let randomX = Int.random(in: 1..<rows) * Int(snakeSize)
        let randomY = Int.random(in: 1..<cols) * Int(snakeSize)
        
        return CGPoint(x: randomX, y: randomY)
    }
}

struct snakeView_Previews: PreviewProvider {
    static var previews: some View {
        snaketView()
        snaketView().colorScheme(.dark)
    }
}
