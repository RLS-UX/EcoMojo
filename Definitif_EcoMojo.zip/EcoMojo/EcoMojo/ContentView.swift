//  EcoMojo
//
//  Created by Groupe environement
//

import SwiftUI

struct ContentView: View {
    @AppStorage ("isDarkMode") private var isDarkMode = false
//Initialisation des couleurs de la tabbar, et des items non selectionné
    init() {
        UITabBar.appearance().barTintColor = UIColor(Color("Color_Nav_Bas"))
        UITabBar.appearance().unselectedItemTintColor = UIColor(Color("Color_Title"))
    }
    var body: some View {
//Tabbar + page selectionner(accentColor)
        TabView {
            Home()
                .tabItem {
                    Image(systemName: "house.fill")
                }
            listgames()
                .tabItem {
                    Image(systemName: "gamecontroller.fill")
                }
            infolist()
                .tabItem {
                    Image(systemName: "book.fill")
                }
            Tchat()
                .tabItem {
                    Image(systemName: "person.2.fill")
                }
            setting()
                .tabItem {
                    Image(systemName: "gearshape.fill")
                }
        }
        .environment(\.colorScheme, isDarkMode ? .dark : .light)
        .accentColor(Color("Color_Selected"))
        
        
        
        
        
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView() //vue normal

    }
}

