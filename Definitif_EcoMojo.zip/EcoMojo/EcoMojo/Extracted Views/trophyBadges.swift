//  EcoMojo
//
//  Created by Groupe environement
//

import SwiftUI



struct oneBadge: View {
    //Déclaration de variable de l'extrated view -> infoBadges
    var badgeColor: Color
    var imgTxt: String
    var statBadge: Int
    var typeBadge: String
    var badgeWidth: CGFloat
    var badgeHeight: CGFloat
    var body: some View {
        
        
        ZStack { //Estétismes de badges
            
            RoundedRectangle(cornerRadius: 40.0, style: .circular)
                .frame(width: badgeWidth, height: badgeHeight)
                .foregroundColor(badgeColor)
                .shadow(color: Color("Color_Shadow"), radius: 4, x: 3, y: 1)
                .opacity(0.8)
            
            HStack(alignment: .center) {
                Image("\(imgTxt)")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 60, height: 60)
                    .foregroundColor(Color("Color_BackGround"))
                    .shadow(color: Color("Color_Shadow"), radius: 4, x: 3, y: 1)
                Text("Ici vous pouvez voir vos \rbadges : \(typeBadge). \rVous êtes à \(statBadge) badges").font(.title2).opacity(0.9)
                
                
            }.padding()
        }
        
        
    } 
    
}

struct trophyBadges_Previews: PreviewProvider {
    static var previews: some View {
        infoBadges()
    }
}
