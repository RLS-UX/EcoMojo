//  EcoMojo
//
//  Created by Groupe environement
//

import SwiftUI

struct ListChat: View {
    //Déclaration de variable de l'extrated view -> Tchat
    var profilImg: String
    var profilName: String
    var lastMessage: String
    var widthTchat: CGFloat
    var heightTchat: CGFloat
    var lastMessageShort: String
    var body: some View {
        
        //Estetisme de la list de tchat
        ZStack {
            RoundedRectangle(cornerRadius: 40.0)
                .frame(width: widthTchat, height: heightTchat)
                .foregroundColor(Color("Color_Title"))
                .opacity(0.8)
                .shadow(color: Color("Color_Shadow"), radius: 4, x: 4, y: 3)
            
            
            HStack(alignment: .top, spacing: 10.0, content: {
                
                
                Image(profilImg)
                    .resizable()
                    .scaledToFit()
                    .clipped()
                    .foregroundColor(Color.gray)
                    .frame(width: widthTchat * 0.17)
                
                //  On recrée un alignement vertical pour les infos USER
                
                VStack {
                    Text(profilName)
                        .font(.title)
                        .bold()
                        .foregroundColor(Color("Color_Corp"))
                    Text(lastMessageShort)
                        .font(.title2)
                        .foregroundColor(Color("Color_Descript"))
                    
                }.frame(width: widthTchat * 0.65)
                .padding(.leading)
            } )
        }
        
    }
    
}


struct ListChat_Previews: PreviewProvider {
    static var previews: some View {
        Tchat()
    }
}
