//  EcoMojo
//
//  Created by Groupe environement
//

import SwiftUI

struct tchatBuble: View {
    //Déclaration de variable de l'extrated view -> TchatDetail
    var inBubble: String
    var bigBubbleW: CGFloat
    var bigBubbleH: CGFloat
    
    //Estetisme des bulles de tchat
    var body: some View {
        Text(inBubble)
            .bold()
            .padding(12)
            .foregroundColor(Color("Color_Corp"))
            .background(Color("Color_Title"))
            .cornerRadius(30)
            .shadow(color: Color("Color_Shadow"), radius: 7, x: 6, y: 5)
            .frame(width: bigBubbleW, height: bigBubbleH, alignment: .top)
    } }

struct tchatBuble_Previews: PreviewProvider {
    static var previews: some View {
        TchatDetail(fullMessage: fakeTchat.first!).colorScheme(.light)
    }
}
