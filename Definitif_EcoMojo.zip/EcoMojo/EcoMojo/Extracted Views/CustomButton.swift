//
//  CustomButton.swift
//  EcoMojo
//
//  Created by Seillier Remy on 01/02/2021.
//

import SwiftUI

struct CustomButton: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CustomButton_Previews: PreviewProvider {
    static var previews: some View {
        CustomButton()
    }
}
