//
//  EcoMojoApp.swift
//  EcoMojo
//
//  Created by Seillier Remy on 01/02/2021.
//

import SwiftUI

@main
struct EcoMojoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
