//  EcoMojo
//
//  Created by Groupe environement
//

import SwiftUI

struct TchatDetail: View {
    let fullMessage: fakeUserTchat
    //Rappel du fake tchat depuis la page précédente
    var body: some View {

        GeometryReader { geo in
        ZStack{ //esthetisme
            Color("Color_BackGround")
                .ignoresSafeArea()

            VStack{
            tchatBuble(inBubble: fullMessage.chatMessage, bigBubbleW: geo.size.width * 0.9, bigBubbleH: geo.size.height * 0.8).animation(.easeInOut(duration: 0.5))
                
                Form(content: {
                    Text("Repondre...")
                })
            } } }
    } }

struct TchatDetail_Previews: PreviewProvider {
    static var previews: some View {
        TchatDetail(fullMessage: fakeTchat.first!)
    }
}
