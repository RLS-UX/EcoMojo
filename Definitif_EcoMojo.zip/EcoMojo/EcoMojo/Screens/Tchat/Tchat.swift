//  EcoMojo
//
//  Created by Groupe environement
//
import SwiftUI

struct Tchat: View {
    @State private var tchatMessage = fakeTchat //Rappel données fakeTchat
    var body: some View {
        NavigationView {
        GeometryReader { geo in
            ZStack {
                Rectangle()
                    .ignoresSafeArea()
                    .foregroundColor(Color("Color_BackGround"))
                VStack {
                    
                    //Boucle +  Extracted View <- ListChat
        ForEach(tchatMessage) { tchatMessage in
                            
                    NavigationLink(destination: TchatDetail(fullMessage: tchatMessage), label: {
                                
                    ListChat(profilImg: tchatMessage.chatProfil, profilName: tchatMessage.chatName, lastMessage: tchatMessage.chatMessage, widthTchat: geo.size.width * 0.9, heightTchat: geo.size.height * 0.15, lastMessageShort: tchatMessage.chatMessageShort)
                            } ).animation(.easeInOut(duration: 0.5))
                        }
                    
                }
            }
            
        }.navigationTitle("Tchat").navigationBarTitleDisplayMode(.inline)
        .navigationBarColor(UIColor(named:"Color_Nav"))
        }
        
    }
}

struct Tchat_Previews: PreviewProvider {
    static var previews: some View {
        Tchat().colorScheme(.light)
        Tchat().colorScheme(.dark)
    }
}
