//  EcoMojo
//
//  Created by Groupe environement
//
import SwiftUI

struct setting: View {
    @AppStorage ("isDarkMode") private var isDarkMode = false
    @State var userSaved = userOne //récupération des données d'Alphred
    var body: some View {
        ZStack{ //couleur de fond
            Color("Color_BackGround")
                .ignoresSafeArea(.all)
            
            NavigationView {//Bar  du haut
                GeometryReader { geo in //adaption aux écraans
                    let widthToggle = (geo.size.width * 0.75)
                    let heightToggle = (geo.size.height * 0.001)
                    VStack {
                        List {
                            HStack {
                                Text("Pseudo :").font(.headline)
                                TextField("Pseudo :", text: $userSaved.userName).foregroundColor(Color("Color_Descript"))
                                    .frame(width: geo.size.width * 0.2, height: geo.size.height * 0.03)
                            }
                            .padding(.trailing)
                            HStack {
                                Text("Age :").font(.headline)
                                TextField("Age :",text: $userSaved.userAge).foregroundColor(Color("Color_Descript"))
                                    .frame(width: geo.size.width * 0.2, height: geo.size.height * 0.03)
                            }
                            .padding(.trailing)
                            //}//Fin de la liste
                            
                            VStack {
                                Text("Notification")
                                    .frame(width: widthToggle, height: heightToggle, alignment: .center)
                                    .foregroundColor(userSaved.notify ? Color("Color_Selected") : Color("Color_NotSelected"))
                                Toggle("Notification", isOn: $userSaved.notify).labelsHidden()
                            }.padding()
                            .overlay(RoundedRectangle(cornerRadius: 15)
                                        .stroke(lineWidth: 2)
                                        .foregroundColor(userSaved.notify ? Color("Color_Selected") : Color("Color_NotSelected")))
                            
                            VStack {
                                Text("Musique")
                                    .frame(width: widthToggle, height: heightToggle, alignment: .center)
                                    .foregroundColor(userSaved.soundMusic ? Color("Color_Selected") : Color("Color_NotSelected"))
                                Toggle("Musique", isOn: $userSaved.soundMusic)
                                    .labelsHidden()
                            }.padding()
                            .overlay(RoundedRectangle(cornerRadius: 15)
                                        .stroke(lineWidth: 2)
                                        .foregroundColor(userSaved.soundMusic ? Color("Color_Selected") : Color("Color_NotSelected")))
                            
                            
                            VStack {
                                Text("Facebook Sync")
                                    .frame(width: widthToggle, height: heightToggle, alignment: .center)
                                    .foregroundColor(userSaved.socialNetwork ? Color("Color_Selected"): Color("Color_NotSelected"))
                                Toggle("Facebook Sync", isOn: $userSaved.socialNetwork).labelsHidden()
                                    .alert(isPresented: $userSaved.socialNetwork) {
                                        Alert(title: Text("Facebook"), message: Text("Compte synchronisé"), dismissButton: Alert.Button.default(Text("Ok"), action: { userSaved.socialNetwork = true }
                                        ))
                                        
                                    }
                            }.padding()
                            .overlay(RoundedRectangle(cornerRadius: 15)
                                        .stroke(lineWidth: 2)
                                        .foregroundColor(userSaved.socialNetwork ? Color("Color_Selected") : Color("Color_NotSelected")))
                            
                            VStack {
                                Text("Mode Nuit")
                                    .frame(width: widthToggle, height: heightToggle, alignment: .center)
                                    .foregroundColor(userSaved.darkMode ? Color("Color_Selected") : Color("Color_NotSelected"))
                                Toggle("Mode Nuit", isOn: $isDarkMode).labelsHidden()
                                    
                                
                            }.padding()
                            .overlay(RoundedRectangle(cornerRadius: 15)
                                        .stroke(lineWidth: 2)
                                        .foregroundColor(userSaved.darkMode ? Color("Color_Selected") : Color("Color_NotSelected")))
                        }
                        .navigationTitle("Réglages").navigationBarTitleDisplayMode(.inline)
                        .navigationBarColor(UIColor(named:"Color_Nav"))
                    } } } } } }
struct setting_Previews: PreviewProvider {
    static var previews: some View {
        setting().colorScheme(.light)
        setting().colorScheme(.dark)
    }
}
