//  EcoMojo
//
//  Created by Groupe environement
//
import SwiftUI

struct EcoDetail: View {
    var fullArticle: DataEcology //rappel de l'article
    
    var body: some View {
        ZStack{ //beaucoup d'efforts pour rendre ça beau...
            Color("Color_BackGround").edgesIgnoringSafeArea(.all)
            VStack{
                ScrollView( .vertical){
                    Text(fullArticle.ecologyTitle).font(.title).padding()
                        .foregroundColor(Color("Color_Other"))
                        .background(Color("Color_Nav"))
                        .cornerRadius(25.0)
                        .multilineTextAlignment(.center)
                    
                    Image(fullArticle.infoImg)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 230.0)
                        .cornerRadius(20.0)
                        .padding()
                        .aspectRatio(contentMode: .fit)
                        .opacity(9)

                        .shadow(color: Color("Color_Shadow"), radius: 7, x: 6, y: 5)
                    Text(fullArticle.newsEcologyFull).padding()
                        .foregroundColor(Color("Color_Other"))
                    
                    Text(fullArticle.source)
                        .foregroundColor(Color("Color_Other"))
                    
                    Text(fullArticle.publication)
                        .foregroundColor(Color("Color_Other"))
                }
            }
        }
    }
}

struct EcoDetail_Previews: PreviewProvider {
    static var previews: some View {
        EcoDetail(fullArticle:ecoDatas[0]).colorScheme(.light)
        EcoDetail(fullArticle:ecoDatas[0]).colorScheme(.dark)
    }
}
