//  EcoMojo
//
//  Created by Groupe environement
//

import SwiftUI

struct infolist: View {
    
    var body: some View {
        NavigationView{
            GeometryReader { geo in
                ScrollView(.vertical){
                    VStack(alignment: .leading) {
                        ForEach(ecoDatas){ article in
                            //boucle qui recupère dans les infos écologies
                            NavigationLink(destination: EcoDetail(fullArticle: article), label: {
                                EcoInfoRow(article: article, widthArticle: geo.size.width * 0.92, heightArticle: geo.size.height * 0.15).padding(.horizontal)
                                
                            })
                        }
                    }
                }.padding(.top).background(Color("Color_BackGround"))
            }
            .navigationTitle("Info").navigationBarTitleDisplayMode(.inline)
            .navigationBarColor(UIColor(named:"Color_Nav"))
        }
    }
}

struct infolist_Previews: PreviewProvider {
    static var previews: some View {
        infolist().colorScheme(.light)
        infolist().colorScheme(.dark)
    }
}
//Extrated view -> design list
struct EcoInfoRow: View {
    var article: DataEcology
    var widthArticle: CGFloat
    var heightArticle: CGFloat
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20.0)
                .frame(width: widthArticle, height: heightArticle)
                .foregroundColor(Color("Color_Title"))
                .opacity(0.8)
                .shadow(color: Color("Color_Shadow"), radius: 4, x: 4, y: 3)
            HStack{
                Image(article.infoImg)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: widthArticle * 0.15)
                    .cornerRadius(115.0)
                    .shadow(color: Color("Color_Shadow"), radius: 7, x: 6, y: 5)
                VStack{
                    
                Text(article.ecologyTitle)
                    .foregroundColor(Color("Color_Other"))
                    .multilineTextAlignment(.center)
                    .frame(width: widthArticle * 0.8,height: heightArticle * 0.8)
                    Text(article.publication)
                        .foregroundColor(Color("Color_Other"))
                        .multilineTextAlignment(.center)
                    
                        
                    }
                
            }.padding(.vertical)
            
            
        }
    }
}
