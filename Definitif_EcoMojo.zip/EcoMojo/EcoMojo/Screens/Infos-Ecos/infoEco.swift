//  EcoMojo
//
//  Created by Groupe environement
//

import SwiftUI

struct infoEco: View {
    let news : DataEcology
    @Binding var showModal : Bool
    
    var body: some View {
        GeometryReader { geo in
            
            ZStack{
                
                Color("Color_BackGround").edgesIgnoringSafeArea(.all)
                VStack{
                    Button(action: {
                        showModal.toggle()//Bouton qui definit "showModal" = false
                        
                        
                    }, label: {
                        Text("Fermer")
                            .bold()
                            .padding()
                            //estetisme du bouton
                            .foregroundColor(Color("Color_Other"))
                        
                        
                    })
                    ScrollView( .vertical){     //permet de scroller
                        Image("\(news.infoImg)")//estetisme de l'article
                            .resizable()
                            .cornerRadius(20.0)
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 230.0, height: 270.0)
                            
                            .shadow(color: Color("Color_Shadow"), radius: 7, x: 6, y: 5)
                            .padding()
                            .aspectRatio(contentMode: .fit)
                        Text("\(news.ecologyTitle)").font(.title)
                            .foregroundColor(Color("Color_Other"))
                            .padding()
                        Text("\(news.newsEcologyFull)")
                            .foregroundColor(Color("Color_Other"))
                            .padding()
                    }
                }
            }
        }
    }
}
struct infoEco_Previews: PreviewProvider {
    static var previews: some View {
        infoEco(news: DataEcology(newsEcologyFull: "Selon une étude de la fin février, publiée par Nature Climate Change, 18 pays développés ont réduit leurs émissions de CO2 sur la période 2005-2015, parmi lesquels la France, le Royaume-Uni, la Belgique, l'Italie ou encore les Etats-Unis. Tandis qu'en 2018, le niveau mondial des émissions a augmenté de 2 %, concernant ces 18 pays, il a baissé de 2,4 % par an sur cette période. Un chiffre qui s'explique notamment par l'abandon des énergies fossiles au profit des énergies renouvelables. ", newsEcologyQuick: "Selon une étude de la fin février, publiée par Nature Climate Change, 18 pays développés ont réduit leurs émissions de CO2 sur la période 200...", ecologyTitle: "18 pays ont réduit leurs CO2", infoImg: "Info_Co2", source: "Source: L'info Durable", publication: "Publié le 26 février 2019"), showModal: .constant(true)).colorScheme(.light)
        infoEco(news: DataEcology(newsEcologyFull: "Selon une étude de la fin février, publiée par Nature Climate Change, 18 pays développés ont réduit leurs émissions de CO2 sur la période 2005-2015, parmi lesquels la France, le Royaume-Uni, la Belgique, l'Italie ou encore les Etats-Unis. Tandis qu'en 2018, le niveau mondial des émissions a augmenté de 2 %, concernant ces 18 pays, il a baissé de 2,4 % par an sur cette période. Un chiffre qui s'explique notamment par l'abandon des énergies fossiles au profit des énergies renouvelables. ", newsEcologyQuick: "Selon une étude de la fin février, publiée par Nature Climate Change, 18 pays développés ont réduit leurs émissions de CO2 sur la période 200...", ecologyTitle: "18 pays ont réduit leurs CO2", infoImg: "Info_Co2", source: "Source: L'info Durable", publication: "Publié le 26 février 2019"), showModal: .constant(true)).colorScheme(.dark)
    }
}
