//  EcoMojo
//
//  Created by Groupe environement
//

import SwiftUI

struct loadingGame: View {
    @State var randomEcoData = ecoDatas.randomElement()!
    //Récupération aléatoire d'une info
    @State var showingDetail = false //Booléen quand = true affiche la modal
    @State var timeRemaining = 100 //valeur max du timer
    @State var timeColor: Color  = Color("Color_Descript") //Couleur varie timer
    @State var timeOpacity: Double = 0.0 //opacité  varie timer
    let timer = Timer.publish(every: 0.05, on: .main, in: .common).autoconnect()
    // mise en place du timer
    var body: some View {
        
  
                            
        GeometryReader { geo in
            
            ZStack{
                Color("Color_BackGround")
                    .opacity((timeOpacity + 0.7))
                
                
                
                VStack{//beaucoup d'efforts pour rendre ça beau...
                    Spacer()
                        .frame(width: geo.size.width * 0.05)
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 45.0)
                            .frame(width: geo.size.width * 0.9,height: geo.size.height * 0.4)
                            .opacity(timeOpacity)
                            .foregroundColor(timeColor)
                            
                        RoundedRectangle(cornerRadius: 45.0)
                            .frame(width: geo.size.width * 0.85,height: geo.size.height * 0.35)
                            .foregroundColor(Color("Color_BackGround"))
                        VStack{
                            Text("Chargement")
                                .foregroundColor(Color("Color_Other"))
                            Text("  \(100 - (timeRemaining))% ")
                                .foregroundColor(timeColor)
                                
                                        .onReceive(timer) { _ in
                                            if timeRemaining > 0 {
                                                timeRemaining -= 1
                                                timeOpacity += 0.006
                                                
                                            } else {
                                                
                                                timeColor = Color("Color_Other")
                                            } }
                                .font(.largeTitle)
                                .frame(width: 100, height: 100)
                                .foregroundColor(timeColor)

                                
                            
                        }
                    }
                    //Passe la Booléenne à true
                    Button(action: {
                        self.showingDetail.toggle()
                    }) {
                        Text("\(randomEcoData.newsEcologyQuick)")
                            .frame(width: geo.size.width * 0.9)
                    }.sheet(isPresented: $showingDetail) {
                        infoEco(news: randomEcoData,showModal: $showingDetail)
                    }
                    
                    
                    Spacer()
                        .frame(height: geo.size.height * 0.04)
                    NavigationLink(destination: snaketView(), label: {
                        Text("Jouer").font(.largeTitle)
                            .opacity(timeOpacity)
                            .foregroundColor(timeColor)
                            .animation(.easeInOut(duration: 1.0))
                        
                        
                            }
                      )
                    
                    Spacer()
                        .frame(height: geo.size.height * 0.3)
                    
                }
            }.edgesIgnoringSafeArea(.all)
            
        }.navigationTitle("Loading")
    }
}

struct loadingGame_Previews: PreviewProvider {
    static var previews: some View {
        loadingGame2()
    }
}
