//  EcoMojo
//
//  Created by Groupe environement
//

import SwiftUI

struct listgames: View {
    
    var body: some View {
        
        NavigationView {
            
            GeometryReader { geo in
                
                ZStack{
                    Color("Color_BackGround")
                    VStack{
                        
                        HStack{
                            Spacer()
                                .frame(width: geo.size.width * 0.05)
                            Image(game1.gameImg)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: geo.size.width * 0.5)
                                .shadow(color: Color("Color_Shadow"), radius: 4, x: 4, y: 3)
                            Spacer()
                                .frame(width: geo.size.width * 0.15,height: geo.size.height * 0.4)
                            
                            //Lien vers page gameDetails
                            NavigationLink(destination: gameDetails(), label: {
                                Text("👀 Voir")
                                    .padding(8)
                                    .background(Color("Color_Voir"))
                                    .cornerRadius(13.0)
                                    .shadow(color: Color("Color_Shadow"), radius: 5, x: 4, y: 3)
                                
                            })
                            
                        }
                        HStack{
                            Spacer()
                                .frame(width: geo.size.width * 0.05)
                            Image(game2.gameImg)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: geo.size.width * 0.5)
                                .shadow(color: Color("Color_Shadow"), radius: 4, x: 4, y: 3)
                            Spacer()
                                .frame(width: geo.size.width * 0.15,height: geo.size.height * 0.4)
                            
                            
                            //Lien vers page gameDetails
                            NavigationLink(destination: gameDetails2(), label: {
                                Text("👀 Voir")
                                    .padding(8)
                                    .background(Color("Color_Voir"))
                                    .cornerRadius(13.0)
                                    .shadow(color: Color("Color_Shadow"), radius: 5, x: 4, y: 3)
                                
                                
                            })
                            
                        }
                    }
                }.edgesIgnoringSafeArea(.all)
            }.navigationTitle("Jeu").navigationBarTitleDisplayMode(.inline)
            .navigationBarColor(UIColor(named:"Color_Nav"))

            
        }
    }
}

struct game_Previews: PreviewProvider {
    static var previews: some View {
        listgames().colorScheme(.light)
        listgames().colorScheme(.dark)
    }
}
