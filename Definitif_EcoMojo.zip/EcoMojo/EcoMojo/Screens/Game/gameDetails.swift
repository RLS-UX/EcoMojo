//  EcoMojo
//
//  Created by Groupe environement
//

import SwiftUI

struct gameDetails: View {
    var body: some View {
        GeometryReader { geo in
            
            ZStack{ //beaucoup d'efforts pour rendre ça beau...
                Color("Color_BackGround")
                
                VStack{
                    
                    HStack{
                        
                        Spacer()
                    }
                    Spacer()
                }
                VStack{
                    Spacer()
                        .frame(width: geo.size.height * 0.1, height: geo.size.height * 0.127)
                    HStack{
                        Spacer()
                            .frame(width: geo.size.width * 0.1)
                        
                        ZStack{
                            
                            Rectangle()
                                .foregroundColor(Color("Color_Other"))
                                .frame(width: geo.size.width * 1.0, height: geo.size.height * 0.75)
                                .cornerRadius(40)
                            Rectangle()
                                .foregroundColor(Color("Color_BackGround"))
                                .frame(width: geo.size.width * 0.95, height: geo.size.height * 0.72)
                                .cornerRadius(40)
                            VStack{
                                Image("GarbageTruck")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: geo.size.width * 0.5)
                                    .shadow(color: Color("Color_Shadow"), radius: 4, x: 4, y: 3)
                                Spacer()
                                    .frame(width: geo.size.width * 0.6, height: geo.size.height * 0.05)
                                Text(game1.gameTitle)
                                    .font(.title)
                                    .foregroundColor(Color("Color_Other"))
                                Text(game1.gameSum)
                                    .frame(width: geo.size.width * 0.6,height: geo.size.height * 0.2)
                                
                                
                            }
                            
                            
                        }
                        
                    }
                    Spacer()
                        .frame(width: geo.size.width * 0.6, height: geo.size.height * 0.01)
                    //Lien vers la page loadingGame
                    NavigationLink(destination: loadingGame(), label: {
                        Image(systemName:"play.circle")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: geo.size.width * 0.2)
                            .foregroundColor(Color("Color_Other"))
                    })
                    
                }
                
                
            }.edgesIgnoringSafeArea(.all)
            
        }
        .navigationTitle("Details")
            }
}


struct gameDetails_Previews: PreviewProvider {
    static var previews: some View {
        gameDetails().colorScheme(.light)
        gameDetails().colorScheme(.dark)
    }
}
