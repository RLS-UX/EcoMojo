//  EcoMojo
//
//  Created by Groupe environement
//

import SwiftUI

struct Home: View {
    @State var userTrophy = trophyAlphred
    @State private var slider = trophyAlphred.pourcentEarthTrophy
    //slider =   % planette
    
    var changeEarth: Image {
        //conditions % -> planete
        if slider == 100 {
            return Image("earth6")
        } else if slider >= 0 && slider <= 20 {
            return Image("earth1")
        } else if slider >= 20 && slider <= 40 {
            return Image("earth2")
        } else if slider >= 40 && slider <= 60 {
            return Image("earth3")
        } else if slider >= 60 && slider <= 80 {
            return Image("earth4")
        } else {
            return Image("earth5")
        }
    }
    
    
    var body: some View {
        GeometryReader { geo in
            let largeTrophy = geo.size.height * 0.15
            var pourcentPlanete: Double = (slider)
            var fireHeight =  CGFloat(slider*2.1)
            NavigationView {
                
                ZStack {
                    Color("Color_BackGround").ignoresSafeArea(.all)
                    
                    VStack {
                        HStack{
                            NavigationLink(destination: infoBadges(), label: {
                                
                                ZStack {
                                    VStack {
                                        ZStack{
                                            RoundedRectangle(cornerRadius: 115.0)
                                                .foregroundColor(.green)
                                                .shadow(color: Color("Color_Shadow"), radius: 4, x: 3, y: 1)
                                                .frame(width: largeTrophy / 3.5 , height: largeTrophy / 3.5)
                                                .opacity(0.9)
                                            Text("\(userTrophy.dayTrophy)")
                                                .foregroundColor(Color("Color_BackGround"))
                                                .bold()
                                        }
                                        
                                        .offset(x: 33, y: 6)
                                        Spacer()
                                            .frame(width: largeTrophy  , height: largeTrophy )
                                    }
                                    Image("Day_Image")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(height: largeTrophy)
                                        .foregroundColor(.green)
                                        .shadow(color: Color("Color_Shadow"), radius: 4, x: 3, y: 1)  
                                }
                                ZStack {
                                    VStack {
                                        ZStack{
                                            RoundedRectangle(cornerRadius: 115.0)
                                                .foregroundColor(.orange)
                                                .shadow(color: Color("Color_Shadow"), radius: 4, x: 3, y: 1)
                                                .frame(width: largeTrophy / 3.5 , height: largeTrophy / 3.5)
                                                .opacity(0.9)
                                            Text("\(userTrophy.weekTrophy)")
                                                .foregroundColor(Color("Color_BackGround"))
                                                .bold()
                                        }
                                        
                                        .offset(x: 33, y: 6)
                                        Spacer()
                                            .frame(width: largeTrophy  , height: largeTrophy )
                                    }
                                    Image("Week_Image")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(height: largeTrophy)
                                        .foregroundColor(.orange)
                                        .shadow(color: Color("Color_Shadow"), radius: 4, x: 3, y: 1)
                                }
                                ZStack {
                                    VStack {
                                        ZStack{
                                            RoundedRectangle(cornerRadius: 115.0)
                                                .foregroundColor(.red)
                                                .shadow(color: Color("Color_Shadow"), radius: 4, x: 3, y: 1)
                                                .frame(width: largeTrophy / 3.5 , height: largeTrophy / 3.5)
                                                .opacity(0.9)
                                            Text("\(userTrophy.monthTrophy)")
                                                .foregroundColor(Color("Color_BackGround"))
                                                .bold()
                                        }
                                        
                                        .offset(x: 33, y: 6)
                                        Spacer()
                                            .frame(width: largeTrophy  , height: largeTrophy )
                                    }
                                    Image("Month_Image")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(height: largeTrophy)
                                        .foregroundColor(.red)
                                        .shadow(color: Color("Color_Shadow"), radius: 4, x: 3, y: 1)
                                }
                            })
                        }
                        Spacer()
                        
                        NavigationLink(destination: infoBadges(), label: {
                            ZStack(alignment: .bottom){
                                
                                changeEarth
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 200)
                                    .shadow(color: Color("Color_Shadow"), radius: 4, x: 3, y: 1)
                                Image("fire")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: fireHeight)
                                    .shadow(color: .red, radius: CGFloat((slider)), x: 0, y: 0)
                                    .shadow(color: .orange, radius: CGFloat((slider*2)), x: 0, y: 0)
                                    .opacity(0.7)
                            }
                        })
                        VStack(alignment: .center, spacing: nil, content: {
                            Text("\(slider, specifier: "%.1f")%")
                                .font(.largeTitle).bold()
                                .foregroundColor(Color("Color_Other"))
                            Text("de votre planete détruite")
                                .font(.title3).bold()
                                .foregroundColor(Color("Color_Other"))
                            Slider(value: $slider, in: 0...100)
                                .opacity(0.1)
                        })//Slider, avec peu de visibiliter
                        Spacer()
                    }
                }
                .navigationTitle("Home")
                .hiddenNavigationBarStyle()
                .animation(.easeInOut(duration: 0.9))
                .transition(.opacity)
                
                
                
                
                
            }
        }
    }
}




struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home().colorScheme(.light)
        Home().colorScheme(.dark)
    }
}
