//  EcoMojo
//
//  Created by Groupe environement
//
import SwiftUI

struct infoBadges: View {
    @State var userTrophy = trophyAlphred //Rappel des trophées d'Alphred
    
    //Extracted View <- trophyBadges
    
    var body: some View {
        ZStack(alignment: .center) {
            Color("Color_BackGround")
                .ignoresSafeArea(.all)
            GeometryReader { geo in
                VStack(alignment: .center, spacing: geo.size.height  *  0.1, content: {
                    Spacer()
                        .frame(width: geo.size.width, height: geo.size.height *   0.1)
                    oneBadge(badgeColor: Color.green, imgTxt: "Day_Image", statBadge: userTrophy.dayTrophy, typeBadge: "Journalier", badgeWidth: geo.size.width *   0.9, badgeHeight: geo.size.height *   0.15)
                    
                    oneBadge(badgeColor: Color.orange, imgTxt: "Week_Image", statBadge: userTrophy.weekTrophy, typeBadge: "Hebdomadaire", badgeWidth: geo.size.width *   0.9, badgeHeight: geo.size.height *   0.15)
                    
                    oneBadge(badgeColor: Color.red, imgTxt: "Month_Image", statBadge: userTrophy.monthTrophy, typeBadge: "Mensuel", badgeWidth: geo.size.width *   0.9, badgeHeight: geo.size.height *   0.15)
                }).animation(.easeInOut(duration: 1.3))
            } }
            .navigationTitle("Infos Badges").navigationBarTitleDisplayMode(.inline)
            .navigationBarColor(UIColor(named:"Color_Nav"))
    }
}


struct infoBadges_Previews: PreviewProvider {
    static var previews: some View {
        infoBadges().colorScheme(.light)
        infoBadges().colorScheme(.dark)
    }
}
