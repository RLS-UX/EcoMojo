//  EcoMojo
//
//  Created by Groupe environement
//
import SwiftUI

//Structure pour les trophées/resultats
struct Trophy {
    var dayTrophy: Int
    var weekTrophy: Int
    var monthTrophy: Int
    var pourcentEarthTrophy: Double
}

//Bibliothèque de jeux
struct GameLibrary {
    var gameTitle: String
    var gameSum: String
    var gameImg: String
}

//News sur l'écologie
struct DataEcology: Identifiable {
    let id = UUID()
    var newsEcologyFull: String
    var newsEcologyQuick: String
    var ecologyTitle  : String
    var infoImg : String
    var source : String
    var publication : String
}

//Donnée de l'utilisateurs
struct PersonnalUser {
    var userName: String
    var userAge: String
    var soundMusic: Bool
    var socialNetwork : Bool
    var notify: Bool
    var darkMode: Bool
}

//Structure fake tchat
struct fakeUserTchat: Identifiable {
    let id = UUID().uuidString
    var chatName: String
    var chatProfil: String
    var chatMessage: String
    var chatMessageShort: String
}
//Structure de l'utilisateur
struct User: Identifiable {
    let id = UUID().uuidString
    let name: String
    let imageProfile: String
    let colorName: String
}


//Structure Modal
struct DetailView: View {
    var body: some View {
        Text("Detail")
    }
}
